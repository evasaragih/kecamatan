@extends('layouts.app')

@section('title', 'Daftar Kelurahan - Kecamatan Lubuk Kilangan')
@section('body-class', 'is-immersive')

@push('styles')
<style>
    .kel-hero {
        position: relative;
        min-height: 82vh;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        color: #fff;
        background: linear-gradient(180deg, rgba(8,9,14,.4) 0%, rgba(8,9,14,.6) 55%, rgba(8,9,14,.94) 100%),
                    url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=1800&q=80') center/cover no-repeat fixed;
        padding: 8rem 1.5rem 5rem;
    }
    .kel-hero .hero-inner { max-width: 760px; margin: 0 auto; }
    .kel-hero h1 {
        font-weight: 800;
        letter-spacing: -.02em;
        font-size: clamp(2.4rem, 5.4vw, 4.4rem);
        line-height: 1.1;
        margin: 1rem 0 1.1rem;
        opacity: 0; animation: heroFadeUp .8s var(--ease) .25s forwards;
    }
    .kel-hero h1 .accent { color: var(--gold-soft); }
    .kel-hero .kicker { justify-content: center; opacity: 0; animation: heroFadeUp .8s var(--ease) .1s forwards; }
    .kel-hero p.lead-text {
        color: rgba(255,255,255,.82);
        max-width: 600px;
        margin: 0 auto 2.5rem;
        font-weight: 300;
        opacity: 0; animation: heroFadeUp .8s var(--ease) .42s forwards;
    }
    .kel-stats {
        display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap;
        opacity: 0; animation: heroFadeUp .8s var(--ease) .58s forwards;
    }
    .kel-stat-box {
        background: rgba(255,255,255,.07);
        border: 1px solid rgba(255,255,255,.14);
        border-radius: var(--radius-sm);
        padding: 1.4rem 2.2rem;
        min-width: 150px;
        backdrop-filter: blur(6px);
    }
    .kel-stat-box .num { font-size: 2rem; font-weight: 800; color: #fff; line-height: 1; }
    .kel-stat-box .label { font-size: .8rem; color: var(--gold-soft); margin-top: .4rem; }

    .kel-list-section { background: var(--paper); padding: clamp(4rem, 8vw, 7rem) 0; }
    .kel-list-header h2 { font-size: clamp(2rem, 3.6vw, 2.8rem); font-weight: 800; letter-spacing: -.02em; }
    .kel-list-header .accent { color: var(--maroon); }
    .kel-list-header p { color: var(--muted); }

    .kel-row-card {
        border-radius: var(--radius-lg);
        overflow: hidden;
        box-shadow: 0 12px 34px rgba(15,10,10,.08);
        background: var(--surface);
        transition: box-shadow .4s var(--ease), transform .4s var(--ease);
    }
    .kel-row-card:hover { box-shadow: 0 26px 55px rgba(15,10,10,.15); transform: translateY(-4px); }
    .kel-row-media {
        position: relative; height: 100%; min-height: 240px;
        background: linear-gradient(155deg, var(--maroon), var(--maroon-deep));
    }
    .kel-row-media img { width: 100%; height: 100%; min-height: 240px; object-fit: cover; }
    .kel-row-initials {
        position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
        font-size: 3rem; font-weight: 800; color: rgba(255,255,255,.85);
    }
    .kel-row-badges { position: absolute; left: 1rem; bottom: 1rem; display: flex; gap: .5rem; }
    .kel-num-badge {
        background: rgba(11,12,16,.55); color: #fff; font-weight: 700; font-size: .8rem;
        padding: .35rem .7rem; border-radius: 999px; backdrop-filter: blur(2px);
    }
    .kel-status-badge {
        background: #2f7d4f; color: #fff; font-weight: 600; font-size: .78rem;
        padding: .35rem .8rem; border-radius: 999px; display: inline-flex; align-items: center; gap: .35rem;
    }
    .kel-status-badge i { font-size: .5rem; }

    .kel-row-body { padding: clamp(1.5rem, 3vw, 2.25rem); }
    .kel-tag {
        display: inline-flex; align-items: center; gap: .4rem;
        background: var(--maroon-tint); color: var(--maroon); font-size: .78rem; font-weight: 600;
        padding: .4rem .9rem; border-radius: 999px;
    }
    .kel-icon-box {
        width: 42px; height: 42px; border-radius: 12px;
        background: var(--maroon-tint); color: var(--maroon);
        display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0;
    }
    .kel-info-line { font-size: .85rem; color: var(--muted); display: flex; align-items: center; gap: .45rem; margin-bottom: .25rem; }
    .kel-side-label { font-size: .85rem; font-weight: 700; color: var(--ink); display: flex; align-items: center; gap: .4rem; }
    .kel-side-count { font-size: .8rem; color: var(--muted-soft); font-weight: 600; }
    .kel-side-empty { font-size: .78rem; color: var(--muted-soft); font-style: italic; }
    .kel-detail-btn {
        border-radius: 999px; font-weight: 600; padding: .7rem 1.6rem;
        background: var(--maroon); border: none; transition: background .3s ease, transform .3s ease;
    }
    .kel-detail-btn:hover { background: var(--maroon-deep); transform: translateY(-3px); }

    /* ===== Peta Interaktif Kelurahan ===== */
    .peta-section { background: var(--ink); padding: clamp(4rem, 8vw, 6rem) 0; color: #fff; }
    .peta-header h2 { font-size: clamp(2rem, 3.6vw, 2.8rem); font-weight: 800; letter-spacing: -.02em; color: #fff; }
    .peta-header .accent { color: var(--gold-soft); }
    .peta-header p { color: rgba(255,255,255,.62); max-width: 620px; }
    .peta-note { color: rgba(255,255,255,.4); font-size: .78rem; }

    .peta-map-card {
        position: relative;
        background: linear-gradient(155deg, var(--ink-soft), #fc1a5a);
        border: 1px solid rgba(255,255,255,.08);
        border-radius: var(--radius-lg);
        padding: clamp(2rem, 4vw, 3rem) 1.5rem 2.5rem;
        min-height: 480px;
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        overflow: hidden;
    }
    .honeycomb { display: flex; flex-direction: column; align-items: center; }
    .honeycomb-row { display: flex; margin-top: -30px; }
    .honeycomb-row.offset { margin-top: -30px; transform: translateX(66px); }
    .hex-btn {
        appearance: none; border: none; padding: 0; cursor: pointer;
        width: 132px; height: 150px; margin: 0 2px;
        clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
        background: rgba(255,255,255,.06);
        border: 1px solid rgba(255,255,255,.16);
        color: rgba(255,255,255,.72);
        display: flex; align-items: center; justify-content: center; text-align: center;
        font-weight: 700; font-size: .82rem; letter-spacing: .01em; line-height: 1.25;
        padding: 0 1.1rem;
        transition: background .35s var(--ease), color .35s ease, transform .35s var(--ease);
    }
    .hex-btn:hover { background: rgba(231,210,161,.16); color: #fff; transform: translateY(-4px); }
    .hex-btn.active {
        background: linear-gradient(155deg, var(--gold), #a9803a);
        color: var(--maroon-deep);
        transform: translateY(-6px);
        box-shadow: 0 18px 34px rgba(201,165,92,.35);
    }
    .peta-caption { margin-top: 1.75rem; text-align: center; color: rgba(255,255,255,.45); font-size: .85rem; font-style: italic; }
    .peta-total-box {
        position: absolute; left: 1.25rem; bottom: 1.25rem;
        background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.12);
        border-radius: var(--radius-sm); padding: .9rem 1.2rem; backdrop-filter: blur(4px);
    }
    .peta-total-box .t-label { font-size: .72rem; color: rgba(255,255,255,.55); }
    .peta-total-box .t-value { font-size: 1.15rem; font-weight: 800; color: var(--gold-soft); }

    .demo-pill {
        display: inline-flex; align-items: center; gap: .5rem;
        background: rgba(231,210,161,.12); border: 1px solid rgba(231,210,161,.3);
        color: var(--gold-soft); font-weight: 700; font-size: .92rem;
        padding: .6rem 1.4rem; border-radius: 999px; margin-bottom: 1.25rem;
    }
    .demo-card {
        background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.1);
        border-radius: var(--radius-sm); padding: 1.2rem 1.4rem; margin-bottom: 1rem;
    }
    .demo-card .d-label { font-size: .82rem; color: rgba(255,255,255,.55); display: flex; align-items: center; gap: .5rem; }
    .demo-card .d-value { font-size: 1.7rem; font-weight: 800; color: #fff; margin: .3rem 0 .15rem; }
    .demo-card .d-sub { font-size: .76rem; color: rgba(255,255,255,.4); }
    .demo-bar { height: 6px; border-radius: 999px; background: rgba(255,255,255,.1); margin-top: .6rem; overflow: hidden; }
    .demo-bar > span { display: block; height: 100%; background: var(--gold); border-radius: 999px; transition: width .5s var(--ease); }
    .demo-gender { display: flex; align-items: center; gap: .6rem; margin-top: .5rem; }
    .demo-gender .g-chip { flex: 1; text-align: center; border-radius: 999px; padding: .4rem 0; font-weight: 700; font-size: .82rem; }
    .demo-gender .g-wanita { background: #b5476a; color: #fff; }
    .demo-gender .g-pria { background: #3b6fa6; color: #fff; }
</style>
@endpush

@section('content')

<section class="kel-hero">
    <div class="hero-inner">
        <span class="kicker kicker-light"><i class="fa-solid fa-map-location-dot me-1"></i> Wilayah Administratif</span>
        <h1>Kelurahan<br><span class="accent">Se-Kecamatan</span></h1>
        <p class="lead-text">Jelajahi informasi lengkap mengenai kelurahan di Kecamatan Lubuk Kilangan, Padang</p>
        <div class="kel-stats">
            <div class="kel-stat-box">
                <div class="num">{{ $kelurahans->count() }}</div>
                <div class="label">Kelurahan</div>
            </div>
            <div class="kel-stat-box">
                <div class="num">24</div>
                <div class="label">Jam Layanan</div>
            </div>
            <div class="kel-stat-box">
                <div class="num">100%</div>
                <div class="label">Dedikasi</div>
            </div>
        </div>
    </div>
</section>

@include('partials.marquee')

<section class="peta-section">
    <div class="container">
        <div class="peta-header text-center mb-5">
            <span class="kicker kicker-light justify-content-center"><i class="fa-solid fa-map-location-dot me-1"></i> Data Wilayah</span>
            <h2 class="mt-2">Peta Interaktif <span class="accent">Kelurahan</span></h2>
            <p class="mx-auto">Klik salah satu kelurahan pada peta untuk melihat gambaran demografinya</p>
        </div>

        <div class="row g-4 align-items-stretch" id="peta-interaktif" data-peta='@json($petaData)'>
            <div class="col-lg-7">
                <div class="peta-map-card">
                    <div class="honeycomb">
                        <div class="honeycomb-row">
                            @foreach($petaData->slice(0, 4) as $item)
                                <button type="button" class="hex-btn" data-slug="{{ $item['slug'] }}">{{ $item['nama'] }}</button>
                            @endforeach
                        </div>
                        <div class="honeycomb-row offset">
                            @foreach($petaData->slice(4, 3) as $item)
                                <button type="button" class="hex-btn" data-slug="{{ $item['slug'] }}">{{ $item['nama'] }}</button>
                            @endforeach
                        </div>
                    </div>
                    <p class="peta-caption">Peta Interaktif 7 Kelurahan &middot; Kecamatan Lubuk Kilangan</p>

                    <div class="peta-total-box">
                        <div class="t-label">Keseluruhan Wilayah Kecamatan</div>
                        <div class="t-value">{{ number_format($totalLuas, 0, ',', '.') }} km² &middot; {{ number_format($totalPenduduk, 0, ',', '.') }} jiwa</div>
                    </div>
                </div>
                <p class="peta-note mt-3">*Kepadatan penduduk dihitung dari data kelurahan. Rasio gender, usia produktif, dan pertumbuhan populasi merupakan data ilustrasi (dummy).</p>
            </div>

            <div class="col-lg-5">
                <div class="demo-pill" id="demo-title"><i class="fa-solid fa-chart-simple"></i> Demografi Kel. ...</div>

                <div class="demo-card">
                    <div class="d-label"><i class="fa-solid fa-people-group"></i> Kepadatan Penduduk</div>
                    <div class="d-value"><span id="demo-kepadatan">-</span></div>
                    <div class="d-sub">Jiwa/km² &middot; dihitung dari data kelurahan</div>
                    <div class="demo-bar"><span id="demo-kepadatan-bar" style="width:0%"></span></div>
                </div>

                <div class="demo-card">
                    <div class="d-label"><i class="fa-solid fa-venus-mars"></i> Rasio Gender</div>
                    <div class="demo-gender">
                        <div class="g-chip g-wanita"><span id="demo-wanita">-</span>%</div>
                        <div class="g-chip g-pria"><span id="demo-pria">-</span>%</div>
                    </div>
                </div>

                <div class="demo-card">
                    <div class="d-label"><i class="fa-solid fa-graduation-cap"></i> Usia Produktif</div>
                    <div class="d-value"><span id="demo-usia">-</span>%</div>
                    <div class="d-sub">15–64 Tahun &middot; Kategori <span id="demo-kategori">-</span></div>
                    <div class="demo-bar"><span id="demo-usia-bar" style="width:0%"></span></div>
                </div>

                <div class="demo-card mb-0">
                    <div class="d-label"><i class="fa-solid fa-arrow-trend-up"></i> Pertumbuhan Populasi</div>
                    <div class="d-value">+<span id="demo-pertumbuhan">-</span>%</div>
                    <div class="d-sub">Annual Growth (dummy)</div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="kel-list-section">
    <div class="container">
        <div class="kel-list-header text-center mb-5">
            <h2>Daftar <span class="accent">Kelurahan</span></h2>
            <p>Pilih kelurahan untuk melihat informasi lengkap, kegiatan, dan pengumuman terkini</p>
        </div>

        <div class="d-flex flex-column gap-4">
            @foreach($kelurahans as $kelurahan)
                <div class="kel-row-card">
                    <div class="row g-0">
                        <div class="col-md-5">
                            <div class="kel-row-media">
                                @if($kelurahan->foto)
                                    <img src="{{ asset('storage/'.$kelurahan->foto) }}" alt="{{ $kelurahan->nama }}">
                                @else
                                    <div class="kel-row-initials">{{ Str::upper(Str::substr($kelurahan->nama, 0, 2)) }}</div>
                                @endif
                                <div class="kel-row-badges">
                                    <span class="kel-num-badge">{{ sprintf('%02d', $loop->iteration) }}</span>
                                    <span class="kel-status-badge"><i class="fa-solid fa-circle"></i> Aktif</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="kel-row-body">
                                <span class="kel-tag"><i class="fa-solid fa-location-dot"></i> Kelurahan {{ $kelurahan->nama }}</span>

                                <div class="d-flex justify-content-between flex-wrap gap-4 mt-3">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <div class="kel-icon-box"><i class="fa-solid fa-building"></i></div>
                                            <h5 class="mb-0 fw-bold">Kelurahan {{ $kelurahan->nama }}</h5>
                                        </div>
                                        <p class="kel-info-line"><i class="fa-solid fa-user"></i> {{ $kelurahan->nama_lurah ?? '-' }}</p>
                                        <p class="kel-info-line mb-0"><i class="fa-solid fa-location-dot"></i> Kelurahan {{ $kelurahan->nama }}</p>
                                    </div>
                                    <div class="text-md-end">
                                        <p class="kel-side-label justify-content-md-end mb-1">
                                            <i class="fa-solid fa-calendar-check text-info"></i> Kegiatan Terbaru
                                            <span class="kel-side-count">0 kegiatan</span>
                                        </p>
                                        <p class="kel-side-empty mb-3">Belum ada kegiatan</p>
                                        <p class="kel-side-label justify-content-md-end mb-1">
                                            <i class="fa-solid fa-bullhorn text-warning"></i> Pengumuman
                                            <span class="kel-side-count">0 pengumuman</span>
                                        </p>
                                        <p class="kel-side-empty mb-0">Tidak ada pengumuman</p>
                                    </div>
                                </div>

                                <div class="text-end mt-4">
                                    <a href="{{ route('kelurahan.show', $kelurahan->slug) }}" class="btn kel-detail-btn text-white">
                                        Lihat Detail Lengkap <i class="fa-solid fa-arrow-right ms-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    const wrap = document.getElementById('peta-interaktif');
    if (!wrap) return;

    const data = JSON.parse(wrap.dataset.peta || '[]');
    if (!data.length) return;

    const maxKepadatan = Math.max(...data.map(d => d.kepadatan));
    const hexButtons = wrap.querySelectorAll('.hex-btn');

    function render(item) {
        document.getElementById('demo-title').innerHTML = '<i class="fa-solid fa-chart-simple"></i> Demografi Kel. ' + item.nama;
        document.getElementById('demo-kepadatan').textContent = item.kepadatan.toLocaleString('id-ID');
        document.getElementById('demo-kepadatan-bar').style.width = Math.max(6, Math.round((item.kepadatan / maxKepadatan) * 100)) + '%';
        document.getElementById('demo-wanita').textContent = item.wanita.toFixed(1);
        document.getElementById('demo-pria').textContent = item.pria.toFixed(1);
        document.getElementById('demo-usia').textContent = item.usia_produktif.toFixed(1);
        document.getElementById('demo-usia-bar').style.width = item.usia_produktif + '%';
        document.getElementById('demo-kategori').textContent = item.kategori_usia;
        document.getElementById('demo-pertumbuhan').textContent = item.pertumbuhan.toFixed(1);
    }

    function setActive(slug) {
        hexButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.slug === slug));
    }

    hexButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            const item = data.find(d => d.slug === this.dataset.slug);
            if (!item) return;
            setActive(this.dataset.slug);
            render(item);
        });
    });

    // Tampilkan kelurahan pertama secara default
    setActive(data[0].slug);
    render(data[0]);
});
</script>
@endpush
