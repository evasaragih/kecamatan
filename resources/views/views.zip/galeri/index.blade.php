@extends('layouts.app')

@section('title', 'Galeri Kegiatan - Kecamatan Lubuk Kilangan')

@section('content')
<section class="container py-5">
    <div class="text-center mb-5">
        <h1 class="fw-bold">Galeri Kegiatan</h1>
        <p class="text-secondary">Dokumentasi kegiatan Kecamatan Lubuk Kilangan</p>
    </div>
</section>

@include('partials.marquee')

<section class="container pb-5">
    <div class="row g-4">
        @forelse($galeris as $foto)
            <div class="col-md-3 col-6">
                <div class="card border-0 shadow-sm h-100">
                    <img src="{{ $foto->foto && $foto->foto !== 'default.jpg' ? asset('storage/'.$foto->foto) : 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=500&q=80' }}" class="card-img-top" style="height:160px;object-fit:cover;" alt="{{ $foto->judul }}">
                    <div class="card-body p-2">
                        <p class="small mb-1 fw-semibold">{{ Str::limit($foto->judul, 45) }}</p>
                        @if($foto->tanggal_kegiatan)
                            <p class="small text-muted mb-0">{{ $foto->tanggal_kegiatan->translatedFormat('d F Y') }}</p>
                        @endif
                    </div>
                </div>
            </div>
        @empty
            <p class="text-center text-secondary">Belum ada dokumentasi.</p>
        @endforelse
    </div>

    <div class="mt-5 d-flex justify-content-center">
        {{ $galeris->links() }}
    </div>
</section>
@endsection
