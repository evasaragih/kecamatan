@extends('layouts.app')

@section('title', 'Kecamatan Lubuk Kilangan - Beranda')

@section('content')

<section class="hero-section text-center">
    <div class="container">
        <h1 class="display-3">KECAMATAN LUBUK KILANGAN</h1>
        <p class="lead">Sebuah Kecamatan Di Kota Padang, Sumatera Barat, Indonesia</p>
    </div>
</section>

<section class="container" style="margin-top:-4rem;">
    <div class="bg-white rounded-4 shadow p-4 p-md-5">
        <span class="badge bg-info-subtle text-info-emphasis badge-pill px-3 py-2 mb-3">PESAN SELAMAT DATANG</span>
        <h2 class="fw-bold">Selamat Datang Di Website Kecamatan Lubuk Kilangan</h2>
        <p class="text-secondary">Website resmi ini hadir untuk memberikan kemudahan akses informasi seputar profil, layanan administrasi, kelurahan, dan kegiatan Kecamatan Lubuk Kilangan kepada seluruh masyarakat.</p>
    </div>
</section>

@include('partials.marquee')

<section class="container py-5">
    <div class="text-center mb-4">
        <h2 class="section-title">Berita Terbaru</h2>
        <p class="text-secondary">Informasi terkini seputar kegiatan dan perkembangan Kecamatan Lubuk Kilangan</p>
        <a href="{{ route('berita.index') }}" class="btn btn-success rounded-pill px-4">Berita</a>
    </div>

    <div class="row g-4">
        @forelse($beritaTerbaru as $berita)
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm card-news">
                    <img src="{{ $berita->foto ? asset('storage/'.$berita->foto) : 'https://images.unsplash.com/photo-1495020689067-958852a7765e?auto=format&fit=crop&w=600&q=80' }}" class="card-img-top" alt="{{ $berita->judul }}">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">{{ Str::limit($berita->judul, 60) }}</h5>
                        <p class="card-text text-secondary small flex-grow-1">{{ Str::limit($berita->ringkasan, 90) }}</p>
                        <p class="text-muted small mb-3">{{ $berita->tanggal_publish->translatedFormat('d F Y') }}</p>
                        <a href="{{ route('berita.show', $berita->slug) }}" class="btn btn-outline-secondary w-100">Baca Selengkapnya</a>
                    </div>
                </div>
            </div>
        @empty
            <p class="text-center text-secondary">Belum ada berita.</p>
        @endforelse
    </div>
</section>

<section class="bg-light py-5">
    <div class="container">
        <div class="text-center mb-4">
            <h2 class="section-title">Kelurahan</h2>
            <p class="text-secondary">Kecamatan Lubuk Kilangan membawahi {{ $totalKelurahan }} kelurahan</p>
            <a href="{{ route('kelurahan.index') }}" class="btn btn-outline-dark rounded-pill px-4">Lihat Semua Kelurahan</a>
        </div>
    </div>
</section>

<section class="container py-5">
    <div class="text-center mb-4">
        <h2 class="section-title">Galeri Kegiatan</h2>
        <p class="text-secondary">Dokumentasi kegiatan Kecamatan Lubuk Kilangan</p>
    </div>
    <div class="row g-3">
        @forelse($galeri as $foto)
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm">
                    <img src="{{ $foto->foto && $foto->foto !== 'default.jpg' ? asset('storage/'.$foto->foto) : 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=500&q=80' }}" class="card-img-top" style="height:150px;object-fit:cover;" alt="{{ $foto->judul }}">
                    <div class="card-body p-2">
                        <p class="small mb-0 fw-semibold">{{ Str::limit($foto->judul, 40) }}</p>
                    </div>
                </div>
            </div>
        @empty
            <p class="text-center text-secondary">Belum ada dokumentasi.</p>
        @endforelse
    </div>
</section>

@endsection
