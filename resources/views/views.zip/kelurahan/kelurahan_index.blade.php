@extends('layouts.app')

@section('title', 'Daftar Kelurahan - Kecamatan Lubuk Kilangan')

@push('styles')
<style>
    .kel-hero {
        background: linear-gradient(180deg, rgba(8,15,34,.92), rgba(8,15,34,.88)), url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat;
        color: #fff;
        padding: 5rem 0 6rem;
        text-align: center;
    }
    .kel-hero .badge-outline {
        display: inline-flex;
        align-items: center;
        gap: .5rem;
        padding: .5rem 1.1rem;
        border-radius: 999px;
        background: rgba(255,255,255,.08);
        border: 1px solid rgba(255,255,255,.18);
        font-size: .8rem;
        font-weight: 600;
        color: #cbd5e1;
        margin-bottom: 1.5rem;
    }
    .kel-hero h1 {
        font-weight: 800;
        letter-spacing: .5px;
        font-size: clamp(2.2rem, 5vw, 3.5rem);
        line-height: 1.15;
    }
    .kel-hero h1 .accent { color: #38bdf8; }
    .kel-hero p.lead-text {
        color: #cbd5e1;
        max-width: 620px;
        margin: 1rem auto 2.5rem;
    }
    .kel-stats {
        display: flex;
        justify-content: center;
        gap: 1rem;
        flex-wrap: wrap;
    }
    .kel-stat-box {
        background: rgba(255,255,255,.06);
        border: 1px solid rgba(255,255,255,.12);
        border-radius: 18px;
        padding: 1.5rem 2.25rem;
        min-width: 150px;
    }
    .kel-stat-box .num { font-size: 2rem; font-weight: 800; color: #fff; line-height: 1; }
    .kel-stat-box .label { font-size: .82rem; color: #93c5fd; margin-top: .4rem; }

    .kel-list-section { background: #fff; padding: 4rem 0; margin-top: -2px; }
    .kel-list-header h2 { font-weight: 800; color: #0f172a; }
    .kel-list-header .accent { color: #2563eb; }
    .kel-list-header p { color: #64748b; }

    .kel-row-card {
        border-radius: 22px;
        overflow: hidden;
        box-shadow: 0 8px 28px rgba(15,23,42,.08);
        background: #fff;
        transition: box-shadow .3s ease, transform .3s ease;
    }
    .kel-row-card:hover {
        box-shadow: 0 18px 40px rgba(15,23,42,.14);
        transform: translateY(-3px);
    }
    .kel-row-media {
        position: relative;
        height: 100%;
        min-height: 220px;
        background: linear-gradient(155deg, #22d3ee, #2563eb);
    }
    .kel-row-media img {
        width: 100%;
        height: 100%;
        min-height: 220px;
        object-fit: cover;
    }
    .kel-row-initials {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        font-weight: 800;
        color: rgba(255,255,255,.85);
    }
    .kel-row-badges {
        position: absolute;
        left: 1rem;
        bottom: 1rem;
        display: flex;
        gap: .5rem;
    }
    .kel-num-badge {
        background: rgba(15,23,42,.55);
        color: #fff;
        font-weight: 700;
        font-size: .8rem;
        padding: .35rem .7rem;
        border-radius: 999px;
        backdrop-filter: blur(2px);
    }
    .kel-status-badge {
        background: #22c55e;
        color: #fff;
        font-weight: 600;
        font-size: .78rem;
        padding: .35rem .8rem;
        border-radius: 999px;
        display: inline-flex;
        align-items: center;
        gap: .35rem;
    }
    .kel-status-badge i { font-size: .5rem; }

    .kel-row-body { padding: 1.75rem 2rem; }
    .kel-tag {
        display: inline-flex;
        align-items: center;
        gap: .4rem;
        background: #eef6ff;
        color: #2563eb;
        font-size: .78rem;
        font-weight: 600;
        padding: .4rem .9rem;
        border-radius: 999px;
    }
    .kel-icon-box {
        width: 42px; height: 42px;
        border-radius: 12px;
        background: #eef6ff;
        color: #2563eb;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
        flex-shrink: 0;
    }
    .kel-info-line {
        font-size: .85rem;
        color: #64748b;
        display: flex;
        align-items: center;
        gap: .45rem;
        margin-bottom: .25rem;
    }
    .kel-side-label {
        font-size: .85rem;
        font-weight: 700;
        color: #0f172a;
        display: flex;
        align-items: center;
        gap: .4rem;
    }
    .kel-side-count { font-size: .8rem; color: #94a3b8; font-weight: 600; }
    .kel-side-empty { font-size: .78rem; color: #94a3b8; font-style: italic; }
    .kel-detail-btn {
        border-radius: 999px;
        font-weight: 600;
        padding: .65rem 1.5rem;
        background: #2563eb;
        border: none;
    }
    .kel-detail-btn:hover { background: #1d4ed8; }
</style>
@endpush

@section('content')

<section class="kel-hero">
    <div class="container">
        <span class="badge-outline"><i class="fa-solid fa-map-location-dot"></i> Wilayah Administratif</span>
        <h1>Kelurahan<br><span class="accent">Se-Kecamatan</span></h1>
        <p class="lead-text">Jelajahi informasi lengkap mengenai kelurahan di Kecamatan Lubuk Kilangan, Padang</p>
        <div class="kel-stats">
            <div class="kel-stat-box">
                <div class="num">{{ $kelurahans->count() }}</div>
                <div class="label">Kelurahan</div>
            </div>
            <div class="kel-stat-box">
                <div class="num">24</div>
                <div class="label">Jam Layanan</div>
            </div>
            <div class="kel-stat-box">
                <div class="num">100%</div>
                <div class="label">Dedikasi</div>
            </div>
        </div>
    </div>
</section>

@include('partials.marquee')

<section class="kel-list-section">
    <div class="container">
        <div class="kel-list-header text-center mb-5">
            <h2>Daftar <span class="accent">Kelurahan</span></h2>
            <p>Pilih kelurahan untuk melihat informasi lengkap, kegiatan, dan pengumuman terkini</p>
        </div>

        <div class="d-flex flex-column gap-4">
            @foreach($kelurahans as $kelurahan)
                <div class="kel-row-card">
                    <div class="row g-0">
                        <div class="col-md-5">
                            <div class="kel-row-media">
                                @if($kelurahan->foto)
                                    <img src="{{ asset('storage/'.$kelurahan->foto) }}" alt="{{ $kelurahan->nama }}">
                                @else
                                    <div class="kel-row-initials">{{ Str::upper(Str::substr($kelurahan->nama, 0, 2)) }}</div>
                                @endif
                                <div class="kel-row-badges">
                                    <span class="kel-num-badge">{{ sprintf('%02d', $loop->iteration) }}</span>
                                    <span class="kel-status-badge"><i class="fa-solid fa-circle"></i> Aktif</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="kel-row-body">
                                <span class="kel-tag"><i class="fa-solid fa-location-dot"></i> Kelurahan {{ $kelurahan->nama }}</span>

                                <div class="d-flex justify-content-between flex-wrap gap-4 mt-3">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <div class="kel-icon-box"><i class="fa-solid fa-building"></i></div>
                                            <h5 class="mb-0 fw-bold">Kelurahan {{ $kelurahan->nama }}</h5>
                                        </div>
                                        <p class="kel-info-line"><i class="fa-solid fa-user"></i> {{ $kelurahan->nama_lurah ?? '-' }}</p>
                                        <p class="kel-info-line mb-0"><i class="fa-solid fa-location-dot"></i> Kelurahan {{ $kelurahan->nama }}</p>
                                    </div>
                                    <div class="text-md-end">
                                        <p class="kel-side-label justify-content-md-end mb-1">
                                            <i class="fa-solid fa-calendar-check text-info"></i> Kegiatan Terbaru
                                            <span class="kel-side-count">0 kegiatan</span>
                                        </p>
                                        <p class="kel-side-empty mb-3">Belum ada kegiatan</p>
                                        <p class="kel-side-label justify-content-md-end mb-1">
                                            <i class="fa-solid fa-bullhorn text-warning"></i> Pengumuman
                                            <span class="kel-side-count">0 pengumuman</span>
                                        </p>
                                        <p class="kel-side-empty mb-0">Tidak ada pengumuman</p>
                                    </div>
                                </div>

                                <div class="text-end mt-4">
                                    <a href="{{ route('kelurahan.show', $kelurahan->slug) }}" class="btn kel-detail-btn text-white">
                                        Lihat Detail Lengkap <i class="fa-solid fa-arrow-right ms-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endsection
