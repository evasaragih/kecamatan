@extends('layouts.app')

@section('title', $kelurahan->nama.' - Kecamatan Lubuk Kilangan')

@section('content')
<section class="container py-5">
    <div class="row g-5">
        <div class="col-lg-5">
            <img src="{{ $kelurahan->foto ? asset('storage/'.$kelurahan->foto) : 'https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=800&q=80' }}" class="img-fluid rounded-4 shadow-sm" alt="{{ $kelurahan->nama }}">
        </div>
        <div class="col-lg-7">
            <h1 class="fw-bold mb-3">{{ $kelurahan->nama }}</h1>
            <ul class="list-group list-group-flush mb-4">
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-secondary">Lurah</span>
                    <span class="fw-semibold">{{ $kelurahan->nama_lurah ?? '-' }}</span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-secondary">Alamat Kantor</span>
                    <span class="fw-semibold text-end">{{ $kelurahan->alamat_kantor ?? '-' }}</span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-secondary">Jumlah Penduduk</span>
                    <span class="fw-semibold">{{ $kelurahan->jumlah_penduduk ? number_format($kelurahan->jumlah_penduduk, 0, ',', '.').' jiwa' : '-' }}</span>
                </li>
                <li class="list-group-item d-flex justify-content-between">
                    <span class="text-secondary">Luas Wilayah</span>
                    <span class="fw-semibold">{{ $kelurahan->luas_wilayah_km2 ? $kelurahan->luas_wilayah_km2.' km²' : '-' }}</span>
                </li>
            </ul>
            <h5 class="fw-bold">Deskripsi</h5>
            <p class="text-secondary">{{ $kelurahan->deskripsi }}</p>
            <a href="{{ route('kelurahan.index') }}" class="btn btn-outline-dark rounded-pill px-4 mt-2">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Daftar Kelurahan
            </a>
        </div>
    </div>
</section>
@endsection
