<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Kecamatan Lubuk Kilangan')</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" type="image/png" href="{{ asset('images/favicon.png') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; color: #1f2937; background:#fff; }
        .navbar-brand-title { line-height:1.2; }
        .navbar-brand-title .brand-main { display:block; font-size:1.05rem; font-weight:700; color:#7f1d2e; }
        .navbar-brand-title .brand-sub { display:block; font-size:.72rem; font-weight:600; letter-spacing:.2px; color:#111827; }
        .navbar-logo { width:46px; height:46px; object-fit:contain; }
        footer .footer-logo { width:44px; height:44px; object-fit:contain; }

        /* Maroon header slide reveal on load - applied per element, not on a wrapping ancestor,
           so it never breaks the navbar's sticky positioning while scrolling */
        @keyframes headerSlideDown {
            from { transform: translateY(-100%); opacity: 0; }
            to   { transform: translateY(0); opacity: 1; }
        }

        /* Social topbar with collapse-on-scroll animation */
        .social-topbar {
            background: linear-gradient(90deg, #5e0f1e, #86182b);
            max-height: 42px;
            opacity: 1;
            overflow: hidden;
            transition: max-height .4s ease, opacity .3s ease, padding .4s ease;
            padding: .5rem 0;
            animation: headerSlideDown .6s cubic-bezier(.22,.61,.36,1) both;
        }
        .social-topbar.is-collapsed {
            max-height: 0;
            opacity: 0;
            padding-top: 0;
            padding-bottom: 0;
        }
        .social-topbar .social-circle {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: 1.5px solid rgba(255,255,255,.85);
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: .78rem;
            margin-right: .5rem;
            transition: background .25s ease, color .25s ease, transform .25s ease;
        }
        .social-topbar .social-circle:hover {
            background: #fff;
            color: #7f1d2e;
            transform: translateY(-2px);
        }

        .navbar {
            transition: box-shadow .3s ease, padding .3s ease;
            border-bottom-color: #f1d9dd !important;
            animation: headerSlideDown .6s cubic-bezier(.22,.61,.36,1) .1s both;
        }
        .navbar.is-scrolled { box-shadow: 0 6px 20px rgba(127,29,46,.15); padding-top:.6rem !important; padding-bottom:.6rem !important; }

        /* Animated underline on nav links */
        .navbar .nav-link {
            font-weight: 500;
            position: relative;
            padding-bottom: 4px;
        }
        .navbar .nav-item:not(.dropdown) > .nav-link::after {
            content: '';
            position: absolute;
            left: 0; bottom: 0;
            width: 0;
            height: 2px;
            background: #7f1d2e;
            transition: width .3s ease;
        }
        .navbar .nav-item:not(.dropdown) > .nav-link:hover::after {
            width: 100%;
        }
        .navbar .dropdown-toggle:hover { color: #7f1d2e; }
        .navbar .dropdown-item:hover { background:#fbeced; color:#7f1d2e; }

        .hero-section {
            background: linear-gradient(180deg, rgba(15,23,42,.55), rgba(15,23,42,.75)), url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat;
            color: #fff;
            padding: 6rem 0 8rem;
        }
        .hero-section h1 { font-weight: 800; letter-spacing: 1px; }
        .badge-pill { border-radius: 999px; }
        .card-news img { height: 190px; object-fit: cover; }
        .card-news .btn { border-radius: 999px; }
        .section-title { font-weight: 700; }
        footer { background:#0f172a; color:#cbd5e1; }
        footer a { color:#e2e8f0; text-decoration:none; }
        .kelurahan-card img { height:160px; object-fit:cover; }

        /* Footer location map */
        .footer-map-frame {
            border-radius: 14px;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,.08);
            filter: grayscale(.15) contrast(1.05);
        }
        .footer-map-link {
            color: #d4a24c;
            text-decoration: none;
            font-weight: 600;
        }
        .footer-map-link:hover { color: #fff; text-decoration: underline; }

        /* ============================================================
           SITE-WIDE ANIMATIONS
           Applies to every page that extends this layout: smooth scroll,
           scroll-reveal on cards/sections, hover polish, hero entrance,
           and a back-to-top button. No changes needed in individual views.
           ============================================================ */
        html { scroll-behavior: smooth; }

        body { animation: pageFadeIn .35s ease both; }
        @keyframes pageFadeIn {
            from { opacity: 0; }
            to   { opacity: 1; }
        }

        /* Hero: fade/slide its own content up on load (above the fold, not scroll-triggered) */
        @keyframes heroFadeUp {
            from { opacity: 0; transform: translateY(26px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        .hero-section h1,
        .hero-section p,
        .hero-section .btn {
            opacity: 0;
            animation: heroFadeUp .7s ease forwards;
        }
        .hero-section h1   { animation-delay: .15s; }
        .hero-section p    { animation-delay: .3s; }
        .hero-section .btn { animation-delay: .45s; }

        /* Generic scroll-reveal utility, applied via JS to cards, columns and section intros */
        .reveal-up {
            opacity: 0;
            transform: translateY(32px);
            transition: opacity .6s cubic-bezier(.22,.61,.36,1), transform .6s cubic-bezier(.22,.61,.36,1);
            will-change: opacity, transform;
        }
        .reveal-up.is-visible { opacity: 1; transform: translateY(0); }

        /* Card hover: lift + soften shadow + zoom the thumbnail */
        .card { transition: transform .35s ease, box-shadow .35s ease; }
        .card:hover { transform: translateY(-8px); box-shadow: 0 18px 34px rgba(15,23,42,.14) !important; }
        .card .card-img-top { overflow: hidden; }
        .card img { transition: transform .5s ease; }
        .card:hover img { transform: scale(1.07); }

        /* Buttons: subtle lift + shine sweep */
        .btn { transition: transform .2s ease, box-shadow .2s ease; }
        .btn:hover { transform: translateY(-2px); }
        .btn-success, .btn-outline-dark, .btn-outline-secondary {
            position: relative;
            overflow: hidden;
        }
        .btn-success::after, .btn-outline-dark::after, .btn-outline-secondary::after {
            content: "";
            position: absolute;
            top: 0; left: -75%;
            width: 50%; height: 100%;
            background: linear-gradient(120deg, transparent, rgba(255,255,255,.45), transparent);
            transform: skewX(-20deg);
            transition: left .6s ease;
        }
        .btn-success:hover::after, .btn-outline-dark:hover::after, .btn-outline-secondary:hover::after { left: 130%; }

        /* Badge pop-in */
        .badge-pill { transition: transform .25s ease; }
        .badge-pill:hover { transform: scale(1.06); }

        /* Footer links: slide-in underline / arrow nudge */
        footer ul.list-unstyled li a { position: relative; transition: color .2s ease, padding-left .2s ease; }
        footer ul.list-unstyled li a:hover { color: #fff; padding-left: 6px; }

        /* Back-to-top button */
        .back-to-top {
            position: fixed;
            right: 22px;
            bottom: 22px;
            width: 46px;
            height: 46px;
            border-radius: 50%;
            background: #7f1d2e;
            color: #fff;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            box-shadow: 0 10px 24px rgba(127,29,46,.35);
            opacity: 0;
            transform: translateY(18px) scale(.8);
            pointer-events: none;
            transition: opacity .3s ease, transform .3s ease, background .25s ease;
            z-index: 1000;
        }
        .back-to-top.is-visible { opacity: 1; transform: translateY(0) scale(1); pointer-events: auto; }
        .back-to-top:hover { background: #5e0f1e; transform: translateY(-4px) scale(1.05); }

        @media (prefers-reduced-motion: reduce) {
            html { scroll-behavior: auto; }
            body,
            .hero-section h1, .hero-section p, .hero-section .btn,
            .reveal-up, .card, .card img, .btn, .back-to-top {
                animation: none !important;
                transition: none !important;
                opacity: 1 !important;
                transform: none !important;
            }
        }
    </style>
    @stack('styles')
</head>
<body>

<div class="social-topbar" id="socialTopbar">
    <div class="container d-flex align-items-center">
        <a href="#" class="social-circle" aria-label="Twitter"><i class="fa-brands fa-twitter"></i></a>
        <a href="#" class="social-circle" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="#" class="social-circle" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
        <a href="#" class="social-circle" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top py-3" id="mainNavbar">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="{{ route('home') }}">
            <img src="{{ asset('images/logo-padang.png') }}" alt="Logo Kota Padang" class="navbar-logo">
            <span class="navbar-brand-title">
                <span class="brand-main">Kecamatan Lubuk Kilangan</span>
                <span class="brand-sub">Pemerintah Kota Padang</span>
            </span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Profil</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="{{ route('profil.show', 'sejarah') }}">Sejarah</a></li>
                        <li><a class="dropdown-item" href="{{ route('profil.show', 'visi-misi') }}">Visi &amp; Misi</a></li>
                        <li><a class="dropdown-item" href="{{ route('profil.show', 'struktur-organisasi') }}">Struktur Organisasi</a></li>
                        <li><a class="dropdown-item" href="{{ route('pejabat.index') }}">Pejabat Struktural</a></li>
                        <li><a class="dropdown-item" href="{{ route('alamat-pemerintahan.index') }}">Alamat Pemerintahan</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Publikasi</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="{{ route('berita.index') }}">Berita</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="{{ route('kelurahan.index') }}">Kelurahan</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Dasawisma</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('galeri.index') }}">Galeri Kegiatan</a></li>
                <li class="nav-item"><a class="nav-link" href="#">PKK</a></li>
            </ul>
        </div>
    </div>
</nav>

@yield('content')

<button id="backToTop" class="back-to-top" aria-label="Kembali ke atas">
    <i class="fa-solid fa-arrow-up"></i>
</button>

<footer class="pt-5 pb-4 mt-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <img src="{{ asset('images/logo-padang.png') }}" alt="Logo Kota Padang" class="footer-logo">
                    <h5 class="text-white mb-0">Kecamatan Lubuk Kilangan</h5>
                </div>
                <p class="small mb-0">Sebuah Kecamatan di Kota Padang, Sumatera Barat, Indonesia.</p>
            </div>
            <div class="col-md-4">
                <h6 class="text-white">Tautan</h6>
                <ul class="list-unstyled small">
                    <li><a href="{{ route('kelurahan.index') }}">Kelurahan</a></li>
                    <li><a href="{{ route('berita.index') }}">Berita</a></li>
                    <li><a href="{{ route('galeri.index') }}">Galeri Kegiatan</a></li>
                    <li><a href="{{ route('admin.login') }}">Login Admin</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h6 class="text-white">Kontak</h6>
                <p class="small mb-0">Jl. Raya Indarung, Kecamatan Lubuk Kilangan, Kota Padang, Sumatera Barat</p>
            </div>
        </div>

        <div class="footer-map mt-5">
            <h6 class="text-white mb-3"><i class="fa-solid fa-location-dot me-2"></i>Lokasi Kantor Camat Lubuk Kilangan</h6>
            <div class="footer-map-frame">
                <iframe
                    src="https://www.google.com/maps?q=-0.9551222,100.421815&z=16&output=embed"
                    width="100%"
                    height="320"
                    style="border:0;"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                    title="Lokasi Kantor Camat Lubuk Kilangan">
                </iframe>
            </div>
            <a href="https://www.google.com/maps?q=-0.9551222,100.421815" target="_blank" rel="noopener" class="footer-map-link small mt-2 d-inline-flex align-items-center gap-1">
                Buka di Google Maps <i class="fa-solid fa-arrow-up-right-from-square" style="font-size:.7rem;"></i>
            </a>
        </div>

        <hr class="border-secondary my-4">
        <p class="small text-center mb-0">&copy; {{ date('Y') }} Kecamatan Lubuk Kilangan. Seluruh hak cipta dilindungi.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    (function () {
        const topbar = document.getElementById('socialTopbar');
        const navbar = document.getElementById('mainNavbar');
        const threshold = 30;

        function handleScroll() {
            const scrolled = window.scrollY > threshold;
            topbar.classList.toggle('is-collapsed', scrolled);
            navbar.classList.toggle('is-scrolled', scrolled);
        }

        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll();
    })();
</script>

<script>
    // ================= SITE-WIDE SCROLL-REVEAL =================
    // Works automatically on every page: no need to edit individual views.
    (function () {
        const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (reduceMotion) return;

        const revealSelectors = [
            '.card',
            '.row > [class*="col-"]',
            '.text-center.mb-4',
            '.bg-white.rounded-4',
            '.kelurahan-card'
        ];

        const targets = new Set();
        revealSelectors.forEach(sel => {
            document.querySelectorAll(sel).forEach(el => {
                // skip elements already handled by their own load-in animation (hero content)
                if (!el.closest('.hero-section')) targets.add(el);
            });
        });

        // group siblings by parent so items in the same row/grid stagger nicely
        const groups = new Map();
        targets.forEach(el => {
            const parent = el.parentElement;
            if (!groups.has(parent)) groups.set(parent, []);
            groups.get(parent).push(el);
        });

        groups.forEach(list => {
            list.forEach((el, i) => {
                el.classList.add('reveal-up');
                el.style.transitionDelay = (Math.min(i, 6) * 0.08) + 's';
            });
        });

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

        targets.forEach(el => observer.observe(el));
    })();

    // ================= BACK TO TOP =================
    (function () {
        const btn = document.getElementById('backToTop');
        if (!btn) return;

        function toggleBtn() {
            btn.classList.toggle('is-visible', window.scrollY > 320);
        }

        btn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        window.addEventListener('scroll', toggleBtn, { passive: true });
        toggleBtn();
    })();
</script>
@stack('scripts')
</body>
</html>
