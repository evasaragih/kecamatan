<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Kecamatan Lubuk Kilangan')</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" type="image/png" href="{{ asset('images/favicon.png') }}">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Poppins', 'ui-sans-serif', 'system-ui'] },
                    colors: {
                        brand: {
                            50: '#eef6ff', 100: '#d9ecff', 500: '#2563eb', 600: '#1d4ed8', 700: '#1e40af',
                        },
                    },
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>body { font-family: 'Poppins', sans-serif; }</style>
    @stack('styles')
</head>
<body class="bg-slate-50 text-slate-800">

<nav class="bg-white border-b border-slate-200 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
            <a href="{{ route('home') }}" class="flex items-center gap-3">
                <img src="{{ asset('images/logo-padang.png') }}" alt="Logo Kota Padang" class="w-11 h-11 object-contain">
                <div class="leading-tight">
                    <span class="block text-[11px] tracking-wide text-slate-500">Kecamatan</span>
                    <span class="block font-bold text-slate-800">LUBUK KILANGAN</span>
                </div>
            </a>

            <div class="hidden lg:flex items-center gap-8 text-sm font-medium">
                <div class="relative group">
                    <button class="flex items-center gap-1 text-brand-600">
                        Profil <i class="fa-solid fa-chevron-down text-[10px]"></i>
                    </button>
                    <div class="absolute left-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-slate-100 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                        <a href="{{ route('profil.show', 'sejarah') }}" class="block px-4 py-2 hover:bg-slate-50">Sejarah</a>
                        <a href="{{ route('profil.show', 'visi-misi') }}" class="block px-4 py-2 hover:bg-slate-50">Visi &amp; Misi</a>
                        <a href="{{ route('profil.show', 'struktur-organisasi') }}" class="block px-4 py-2 hover:bg-slate-50">Struktur Organisasi</a>
                        <a href="{{ route('pejabat.index') }}" class="block px-4 py-2 hover:bg-slate-50">Pejabat Struktural</a>
                        <a href="{{ route('alamat-pemerintahan.index') }}" class="block px-4 py-2 hover:bg-slate-50">Alamat Pemerintahan</a>
                    </div>
                </div>
                <div class="relative group">
                    <button class="flex items-center gap-1 hover:text-brand-600">
                        Publikasi <i class="fa-solid fa-chevron-down text-[10px]"></i>
                    </button>
                    <div class="absolute left-0 mt-2 w-44 bg-white rounded-xl shadow-lg border border-slate-100 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                        <a href="{{ route('berita.index') }}" class="block px-4 py-2 hover:bg-slate-50">Berita</a>
                    </div>
                </div>
                <a href="{{ route('kelurahan.index') }}" class="hover:text-brand-600">Kelurahan</a>
                <a href="#" class="hover:text-brand-600">Dasawisma</a>
                <a href="{{ route('galeri.index') }}" class="hover:text-brand-600">Galeri Kegiatan</a>
                <a href="#" class="hover:text-brand-600">PKK</a>
            </div>

            <button class="lg:hidden text-slate-600" onclick="document.getElementById('mobileMenu').classList.toggle('hidden')">
                <i class="fa-solid fa-bars text-xl"></i>
            </button>
        </div>

        <div id="mobileMenu" class="hidden lg:hidden pb-4 space-y-1 text-sm font-medium">
            <a href="{{ route('profil.show', 'sejarah') }}" class="block py-2">Sejarah</a>
            <a href="{{ route('pejabat.index') }}" class="block py-2">Pejabat Struktural</a>
            <a href="{{ route('alamat-pemerintahan.index') }}" class="block py-2">Alamat Pemerintahan</a>
            <a href="{{ route('kelurahan.index') }}" class="block py-2">Kelurahan</a>
            <a href="{{ route('berita.index') }}" class="block py-2">Berita</a>
            <a href="{{ route('galeri.index') }}" class="block py-2">Galeri Kegiatan</a>
        </div>
    </div>
</nav>

@yield('content')

<footer class="bg-slate-900 text-slate-300 mt-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div class="grid md:grid-cols-3 gap-8 text-sm">
            <div>
                <h5 class="text-white font-semibold mb-2">Kecamatan Lubuk Kilangan</h5>
                <p class="text-slate-400">Sebuah Kecamatan di Kota Padang, Sumatera Barat, Indonesia.</p>
            </div>
            <div>
                <h6 class="text-white font-semibold mb-2">Tautan</h6>
                <ul class="space-y-1 text-slate-400">
                    <li><a href="{{ route('kelurahan.index') }}" class="hover:text-white">Kelurahan</a></li>
                    <li><a href="{{ route('alamat-pemerintahan.index') }}" class="hover:text-white">Alamat Pemerintahan</a></li>
                    <li><a href="{{ route('admin.login') }}" class="hover:text-white">Login Admin</a></li>
                </ul>
            </div>
            <div>
                <h6 class="text-white font-semibold mb-2">Kontak</h6>
                <p class="text-slate-400">Jl. Raya Indarung, Kecamatan Lubuk Kilangan, Kota Padang, Sumatera Barat</p>
            </div>
        </div>
        <hr class="border-slate-700 my-6">
        <p class="text-center text-slate-500 text-xs">&copy; {{ date('Y') }} Kecamatan Lubuk Kilangan. Seluruh hak cipta dilindungi.</p>
    </div>
</footer>

@stack('scripts')
</body>
</html>
