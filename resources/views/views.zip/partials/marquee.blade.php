{{-- Tulisan berjalan diagonal - drop-in partial, style sudah menyatu (scoped di file ini) --}}
<div class="marquee-strip" role="presentation" aria-hidden="true">
    <div class="marquee-track-wrap">
        <div class="marquee-track">
            @for ($i = 0; $i < 2; $i++)
                <span class="marquee-item">KECAMATAN LUBUK KILANGAN</span>
                <span class="marquee-sep"><i class="fa-solid fa-sparkle"></i></span>
                <span class="marquee-item marquee-outline">PADANG, SUMATERA BARAT</span>
                <span class="marquee-sep"><i class="fa-solid fa-sparkle"></i></span>
                <span class="marquee-item">KECAMATAN LUBUK KILANGAN</span>
                <span class="marquee-sep"><i class="fa-solid fa-sparkle"></i></span>
                <span class="marquee-item marquee-outline">PADANG, SUMATERA BARAT</span>
                <span class="marquee-sep"><i class="fa-solid fa-sparkle"></i></span>
            @endfor
        </div>
    </div>
</div>

<style>
    .marquee-strip {
        position: relative;
        transform: skewY(-2.5deg);
        background: #fff;
        border-top: 4px solid #d4a24c;
        border-bottom: 4px solid #d4a24c;
        overflow: hidden;
        margin: 3.5rem 0;
        box-shadow: 0 14px 34px rgba(15, 23, 42, .1);
    }
    .marquee-track-wrap {
        transform: skewY(2.5deg);
        padding: 20px 0;
    }
    .marquee-track {
        display: flex;
        align-items: center;
        width: max-content;
        white-space: nowrap;
        animation: marqueeScroll 26s linear infinite;
    }
    .marquee-strip:hover .marquee-track {
        animation-play-state: paused;
    }
    @keyframes marqueeScroll {
        from { transform: translateX(0); }
        to   { transform: translateX(-50%); }
    }
    .marquee-item {
        display: inline-block;
        font-family: 'Poppins', sans-serif;
        font-weight: 800;
        font-size: clamp(1.3rem, 2.4vw, 2.1rem);
        letter-spacing: .5px;
        color: #7f1d2e;
        padding: 0 1.4rem;
    }
    .marquee-item.marquee-outline {
        color: transparent;
        -webkit-text-stroke: 1.4px #d4a24c;
        text-stroke: 1.4px #d4a24c;
    }
    .marquee-sep {
        color: #d4a24c;
        font-size: 1.1rem;
        padding: 0 .3rem;
    }

    @media (max-width: 576px) {
        .marquee-strip { margin: 2.25rem 0; }
        .marquee-track-wrap { padding: 14px 0; }
    }

    @media (prefers-reduced-motion: reduce) {
        .marquee-track { animation: none; }
    }
</style>
