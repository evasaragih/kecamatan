@extends('layouts.app')

@section('title', $page->judul.' - Kecamatan Lubuk Kilangan')

@section('content')
<section class="container py-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="fw-bold mb-4">{{ $page->judul }}</h1>
            @if($page->foto)
                <img src="{{ asset('storage/'.$page->foto) }}" class="img-fluid rounded-4 mb-4" alt="{{ $page->judul }}">
            @endif
            <div class="fs-6" style="white-space: pre-line;">{{ $page->konten }}</div>
        </div>
    </div>
</section>
@endsection
